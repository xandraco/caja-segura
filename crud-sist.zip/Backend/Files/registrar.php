<?php 
  include("../config/conexion.php");
  $conn = conectar();
  $nombre = $_POST['nombre'];
  $apaterno = $_POST['apaterno'];
  $amaterno = $_POST['amaterno'];
  $email = $_POST['email'];
  $password = $_POST['password'];

  $passwordHash = password_hash($password, PASSWORD_BCRYPT);

  $queryInsert = "INSERT INTO usuarios
    VALUES(null, '$nombre', '$apaterno', '$amaterno', '$email', '$passwordHash')";
  
  $result = mysqli_query($conn, $queryInsert);
  if ($result) {
    Header("Location: ../../index.html");
  }
?>
